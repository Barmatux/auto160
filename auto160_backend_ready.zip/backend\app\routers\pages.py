from urllib.parse import urlencode

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import RedirectResponse
from jose import JWTError
from sqlalchemy import desc
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import CarListing, CatalogItem, CatalogItemPhoto, User, UserRole
from app.security import decode_token, is_token_revoked
from app.storage import generate_download_url

router = APIRouter(tags=["pages"])
templates = Jinja2Templates(directory="app/templates")


def _resolve_user_from_request(request: Request, db: Session) -> User | None:
    token = request.cookies.get("access_token")
    if not token:
        return None
    try:
        payload = decode_token(token)
    except JWTError:
        return None
    if payload.get("type") != "access" or is_token_revoked(payload):
        return None
    email = payload.get("sub")
    if not email:
        return None
    return db.query(User).filter(User.email == email).first()


def _template_context(request: Request, current_user: User | None) -> dict:
    return {
        "request": request,
        "current_user": current_user,
        "is_authenticated": current_user is not None,
        "is_admin": current_user is not None and current_user.role == UserRole.admin,
    }


def _build_cover_url_map(item_ids: list[int], db: Session) -> dict[int, str]:
    if not item_ids:
        return {}
    photos = (
        db.query(CatalogItemPhoto)
        .filter(CatalogItemPhoto.catalog_item_id.in_(item_ids))
        .order_by(CatalogItemPhoto.is_cover.desc(), CatalogItemPhoto.sort_order.asc(), CatalogItemPhoto.id.asc())
        .all()
    )
    cover_map: dict[int, str] = {}
    for photo in photos:
        if photo.catalog_item_id in cover_map:
            continue
        cover_map[photo.catalog_item_id] = generate_download_url(photo.storage_key)
    return cover_map


def _distinct_values(db: Session, column):
    return [row[0] for row in db.query(column).filter(column.isnot(None)).distinct().order_by(column.asc()).all() if row[0]]


def _year_options(db: Session) -> list[int]:
    from_values = [row[0] for row in db.query(CatalogItem.year_from).filter(CatalogItem.year_from.isnot(None)).distinct().all()]
    to_values = [row[0] for row in db.query(CatalogItem.year_to).filter(CatalogItem.year_to.isnot(None)).distinct().all()]
    years = sorted({*from_values, *to_values})
    return years


def _parse_optional_year(value: str | None) -> int | None:
    if value is None:
        return None
    raw = value.strip()
    if raw == "":
        return None
    try:
        year = int(raw)
    except ValueError:
        return None
    if year < 1950 or year > 2100:
        return None
    return year


def _make_model_map(db: Session) -> dict[str, list[str]]:
    rows = (
        db.query(CatalogItem.make, CatalogItem.model)
        .filter(CatalogItem.make.isnot(None), CatalogItem.model.isnot(None))
        .distinct()
        .order_by(CatalogItem.make.asc(), CatalogItem.model.asc())
        .all()
    )
    mapping: dict[str, list[str]] = {}
    for make, model in rows:
        if not make or not model:
            continue
        mapping.setdefault(make, []).append(model)
    return mapping


@router.get("/")
def home(request: Request, db: Session = Depends(get_db)):
    current_user = _resolve_user_from_request(request, db)
    query = db.query(CatalogItem)
    latest = query.order_by(desc(CatalogItem.created_at)).limit(5).all()
    context = _template_context(request, current_user)
    context["latest"] = latest
    context["cover_urls"] = _build_cover_url_map([item.id for item in latest], db)
    return templates.TemplateResponse(request, "index.html", context)


@router.get("/catalog")
def catalog(
    request: Request,
    make: str | None = Query(default=None),
    model: str | None = Query(default=None),
    body_type: str | None = Query(default=None),
    export_country: str | None = Query(default=None),
    fuel_type: str | None = Query(default=None),
    transmission: str | None = Query(default=None),
    year_from: str | None = Query(default=None),
    year_to: str | None = Query(default=None),
    sort: str = Query(default="newest"),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=12, ge=1, le=50),
    db: Session = Depends(get_db),
):
    current_user = _resolve_user_from_request(request, db)
    query = db.query(CatalogItem)
    parsed_year_from = _parse_optional_year(year_from)
    parsed_year_to = _parse_optional_year(year_to)

    if make:
        query = query.filter(CatalogItem.make.ilike(f"%{make}%"))
    if model:
        query = query.filter(CatalogItem.model.ilike(f"%{model}%"))
    if body_type:
        query = query.filter(CatalogItem.body_type.ilike(f"%{body_type}%"))
    if export_country:
        query = query.filter(CatalogItem.export_country.ilike(f"%{export_country}%"))
    if fuel_type:
        query = query.filter(CatalogItem.fuel_type.ilike(f"%{fuel_type}%"))
    if transmission:
        query = query.filter(CatalogItem.transmission.ilike(f"%{transmission}%"))
    if parsed_year_from is not None:
        query = query.filter(CatalogItem.year_from >= parsed_year_from)
    if parsed_year_to is not None:
        query = query.filter(CatalogItem.year_to <= parsed_year_to)

    total = query.count()
    offset = (page - 1) * page_size
    if sort == "price_asc":
        query = query.order_by(CatalogItem.min_price_rub.asc(), CatalogItem.created_at.desc())
    elif sort == "price_desc":
        query = query.order_by(CatalogItem.min_price_rub.desc(), CatalogItem.created_at.desc())
    elif sort == "year_desc":
        query = query.order_by(CatalogItem.year_from.desc(), CatalogItem.created_at.desc())
    elif sort == "year_asc":
        query = query.order_by(CatalogItem.year_from.asc(), CatalogItem.created_at.desc())
    else:
        query = query.order_by(desc(CatalogItem.created_at))

    listings = query.offset(offset).limit(page_size).all()
    context = _template_context(request, current_user)
    context["listings"] = listings
    context["cover_urls"] = _build_cover_url_map([item.id for item in listings], db)
    context["filters"] = {
        "make": make or "",
        "model": model or "",
        "body_type": body_type or "",
        "export_country": export_country or "",
        "fuel_type": fuel_type or "",
        "transmission": transmission or "",
        "year_from": parsed_year_from if parsed_year_from is not None else "",
        "year_to": parsed_year_to if parsed_year_to is not None else "",
        "sort": sort,
    }
    context["options"] = {
        "make": _distinct_values(db, CatalogItem.make),
        "model": _distinct_values(db, CatalogItem.model),
        "body_type": _distinct_values(db, CatalogItem.body_type),
        "export_country": _distinct_values(db, CatalogItem.export_country),
        "fuel_type": _distinct_values(db, CatalogItem.fuel_type),
        "transmission": _distinct_values(db, CatalogItem.transmission),
        "years": _year_options(db),
    }
    context["make_model_map"] = _make_model_map(db)
    context["page"] = page
    context["page_size"] = page_size
    context["total"] = total
    context["total_pages"] = max(1, (total + page_size - 1) // page_size)
    context["has_prev"] = page > 1
    context["has_next"] = offset + len(listings) < total

    query_params = {
        "make": make or None,
        "model": model or None,
        "body_type": body_type or None,
        "export_country": export_country or None,
        "fuel_type": fuel_type or None,
        "transmission": transmission or None,
        "year_from": parsed_year_from,
        "year_to": parsed_year_to,
        "sort": sort if sort else None,
        "page_size": page_size,
    }

    def build_page_url(page_num: int) -> str:
        params = {k: v for k, v in query_params.items() if v is not None and v != ""}
        params["page"] = page_num
        return "/catalog?" + urlencode(params)

    context["prev_url"] = build_page_url(page - 1) if context["has_prev"] else None
    context["next_url"] = build_page_url(page + 1) if context["has_next"] else None
    return templates.TemplateResponse(request, "catalog.html", context)


@router.get("/catalog/item/{item_id}")
def catalog_item_detail(request: Request, item_id: int, db: Session = Depends(get_db)):
    current_user = _resolve_user_from_request(request, db)
    item = db.query(CatalogItem).filter(CatalogItem.id == item_id).first()
    if not item:
        return templates.TemplateResponse(request, "catalog_item_detail.html", {"request": request, "item": None, "photos": []})

    photos = (
        db.query(CatalogItemPhoto)
        .filter(CatalogItemPhoto.catalog_item_id == item_id)
        .order_by(CatalogItemPhoto.is_cover.desc(), CatalogItemPhoto.sort_order.asc(), CatalogItemPhoto.id.asc())
        .all()
    )
    photo_urls = [generate_download_url(photo.storage_key) for photo in photos]
    context = _template_context(request, current_user)
    context["item"] = item
    context["photos"] = photo_urls
    return templates.TemplateResponse(request, "catalog_item_detail.html", context)


@router.get("/catalog/{listing_id}")
def catalog_item(request: Request, listing_id: int, db: Session = Depends(get_db)):
    current_user = _resolve_user_from_request(request, db)
    listing = db.query(CarListing).filter(CarListing.id == listing_id).first()
    if listing and listing.status != ListingStatus.published:
        if current_user is None or current_user.role != UserRole.admin:
            listing = None
    context = _template_context(request, current_user)
    context["listing"] = listing
    return templates.TemplateResponse(request, "listing_detail.html", context)


@router.get("/login")
def login_page(request: Request, db: Session = Depends(get_db)):
    current_user = _resolve_user_from_request(request, db)
    if current_user:
        return RedirectResponse(url="/", status_code=302)
    return templates.TemplateResponse(request, "login.html", _template_context(request, current_user))


@router.get("/register")
def register_page(request: Request, db: Session = Depends(get_db)):
    current_user = _resolve_user_from_request(request, db)
    if current_user:
        return RedirectResponse(url="/", status_code=302)
    return templates.TemplateResponse(request, "register.html", _template_context(request, current_user))


@router.get("/create-listing")
def create_listing_page(request: Request, db: Session = Depends(get_db)):
    current_user = _resolve_user_from_request(request, db)
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    if current_user.role != UserRole.admin:
        return RedirectResponse(url="/", status_code=302)
    return templates.TemplateResponse(request, "create_listing.html", _template_context(request, current_user))


@router.get("/profile/my-listings")
def profile_my_listings(request: Request, db: Session = Depends(get_db)):
    current_user = _resolve_user_from_request(request, db)
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    if current_user.role != UserRole.admin:
        return RedirectResponse(url="/", status_code=302)
    listings = db.query(CatalogItem).order_by(desc(CatalogItem.created_at)).all()
    context = _template_context(request, current_user)
    context["listings"] = listings
    context["cover_urls"] = _build_cover_url_map([item.id for item in listings], db)
    return templates.TemplateResponse(request, "profile_listings.html", context)


@router.get("/admin/catalog/{item_id}/photos")
def admin_catalog_item_photos(request: Request, item_id: int, db: Session = Depends(get_db)):
    current_user = _resolve_user_from_request(request, db)
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    if current_user.role != UserRole.admin:
        return RedirectResponse(url="/", status_code=302)

    item = db.query(CatalogItem).filter(CatalogItem.id == item_id).first()
    if not item:
        return RedirectResponse(url="/profile/my-listings", status_code=302)

    photos = (
        db.query(CatalogItemPhoto)
        .filter(CatalogItemPhoto.catalog_item_id == item_id)
        .order_by(CatalogItemPhoto.is_cover.desc(), CatalogItemPhoto.sort_order.asc(), CatalogItemPhoto.id.asc())
        .all()
    )
    photo_cards = [
        {
            "id": p.id,
            "is_cover": p.is_cover,
            "sort_order": p.sort_order,
            "content_type": p.content_type,
            "file_url": generate_download_url(p.storage_key),
        }
        for p in photos
    ]

    context = _template_context(request, current_user)
    context["item"] = item
    context["photos"] = photo_cards
    return templates.TemplateResponse(request, "admin_catalog_photos.html", context)


@router.get("/admin/users")
def admin_users_page(request: Request, db: Session = Depends(get_db)):
    current_user = _resolve_user_from_request(request, db)
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    if current_user.role != UserRole.admin:
        return RedirectResponse(url="/", status_code=302)
    users = db.query(User).order_by(User.created_at.desc()).all()
    context = _template_context(request, current_user)
    context["users"] = users
    return templates.TemplateResponse(request, "admin_users.html", context)


@router.get("/logout")
def logout_page():
    response = RedirectResponse(url="/login", status_code=302)
    response.delete_cookie("access_token", path="/")
    response.delete_cookie("refresh_token", path="/")
    return response
